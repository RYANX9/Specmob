'use client'

import { useState, Suspense } from 'react'
import Navbar from '@/app/components/Navbar'
import Footer from '@/app/components/Footer'
import { useToast } from '@/app/components/Toast'
import { api } from '@/lib/api'
import { c, space } from '@/lib/tokens'
import type { Phone, PhoneVariant, TradeInResponse } from '@/lib/types'
import {
  CustomStyles,
  Hero,
  StepsGuide,
  SelectedPhoneChip,
  VariantPicker,
  PhonePicker,
  ConditionForm,
  ResultsView,
  BudgetRecommendations,
  type TradeInPayload,
} from './TradeInParts'

function TradeInContent() {
  const { toast } = useToast()
  const [phone, setPhone] = useState<Phone | null>(null)
  const [variant, setVariant] = useState<PhoneVariant | null>(null)
  const [result, setResult] = useState<TradeInResponse | null>(null)
  const [submitting, setSubmitting] = useState(false)

  const hasStarted = phone !== null
  const variants = phone?.variants ?? []
  const variantRequired = variants.length > 0

  const selectPhone = (p: Phone) => {
    setPhone(p)
    // auto-pick the only variant so single-SKU phones don't add a step
    setVariant(p.variants && p.variants.length === 1 ? p.variants[0] : null)
  }

  const handleSubmit = async (payload: TradeInPayload) => {
    if (!phone) return
    setSubmitting(true)
    try {
      const res = await api.tradein.estimate({
        phone_id: phone.id,
        variant_id: variant?.id,
        ...payload,
      })
      setResult(res)
      window.scrollTo({ top: 0, behavior: 'smooth' })
    } catch {
      toast('Could not calculate a trade-in estimate', 'error')
    } finally {
      setSubmitting(false)
    }
  }

  const changePhone = () => {
    setPhone(null)
    setVariant(null)
    setResult(null)
  }
  const backFromForm = () => setPhone(null)
  const backFromResults = () => setResult(null)

  return (
    <div style={{ minHeight: '100vh', background: c.bg }}>
      <CustomStyles />

      <Navbar />

      <Hero hasStarted={hasStarted} />

      <main
        style={{
          maxWidth: result ? 1100 : 900,
          margin: '0 auto',
          padding: hasStarted ? '48px 24px 80px' : '0 24px 80px',
        }}
      >
        {!hasStarted && <StepsGuide hasStarted={hasStarted} />}

        {/* Search */}
        {!hasStarted && (
          <div style={{ maxWidth: 520, margin: '0 auto', padding: `${space['2xl']}px 0 ${space['4xl']}px` }}>
            <PhonePicker onSelect={selectPhone} />
          </div>
        )}

        {/* Selected chip */}
        {phone && (
          <div style={{ maxWidth: 720, margin: '0 auto' }}>
            <SelectedPhoneChip phone={phone} variant={variant} onChange={changePhone} />
          </div>
        )}

        {/* Variant picker — only when the phone has more than one SKU */}
        {phone && !result && variants.length > 1 && (
          <VariantPicker variants={variants} selected={variant} onSelect={setVariant} />
        )}

        {/* Condition form */}
        {phone && !result && (
          <ConditionForm
            variantRequired={variantRequired}
            variantSelected={variant !== null}
            onSubmit={handleSubmit}
            submitting={submitting}
            onBack={backFromForm}
          />
        )}

        {/* Results */}
        {phone && result && (
          <>
            <ResultsView phone={phone} result={result} onBack={backFromResults} />
            <BudgetRecommendations phone={phone} result={result} />
          </>
        )}
      </main>

      <Footer />
    </div>
  )
}

export default function TradeInClient() {
  return (
    <Suspense fallback={null}>
      <TradeInContent />
    </Suspense>
  )
}